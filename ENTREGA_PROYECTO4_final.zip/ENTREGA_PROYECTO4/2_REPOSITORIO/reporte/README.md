# Reporte IEEE (LaTeX)

Fuente del informe del Proyecto 4 en formato IEEE (`IEEEtran`). Compilar con pdfLaTeX + BibTeX
(`pdflatex main && bibtex main && pdflatex main && pdflatex main`) o subir esta carpeta a Overleaf.

Las tablas (`tablas/`) y figuras (`figuras/`) se generan desde `../resultados/` sin resolver ningún modelo:

    python scripts/generar_tablas_figuras.py

(requiere `matplotlib` y los módulos de `../codigo/`, que importan `gurobipy`; basta la licencia limitada).
La última página (declaración de autoría y firmas) usa `figuras/firmas_proyecto4.png`.
