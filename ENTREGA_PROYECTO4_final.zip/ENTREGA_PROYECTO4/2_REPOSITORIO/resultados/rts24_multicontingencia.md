# Reto 1 - IEEE RTS-24, multicontingencia (Tabla X)

22 escenarios (16 de demanda + 6 contingencias), presupuesto 30 M EUR. Limite de tiempo por corrida: 7200.0 s.

**Dos variantes de pesos**: *impresos* (0.25 y 21 x 0.0357, suma = 0.9997) y *exactos* (0.25 y 0.75/21 = 1/28 = 0.035714, suma = 1). La segunda es una inferencia: los 0.0357 impresos son 1/28 redondeado; se valida mas abajo porque reproduce el bienestar medio de la Tabla X (717.97) y la suma de probabilidades debe ser 1.

Bienestar medio del plan publicado evaluado con este modelo (paper = 717.97):

| Bloques | Pesos impresos | Pesos exactos |
|---|---:|---:|
| exactos | 717.757 | 717.972 |
| impresos | 717.946 | 718.160 |

Bloques: 'exactos' = inferencia (80/10/10 % y 40/30/30 %); 'impresos' = Tabla VI tal cual. Se reportan ambas.

| Formulacion | Bloques | Pesos | Estado | Plan | Inversion (M EUR) | Bienestar medio (M EUR/ano) | Objetivo | Gap | CPU |
|---|---|---|---|---|---:|---:|---:|---:|---:|
| **Paper (Tabla X)** | - | - | - | 3-9, 6-10, 7-8 (2), 10-11, 11-13, 13-14 | 28.64 | 717.97 | - | - | 5.43 h (CPLEX 11) |
| Reproducido: oraculo (un nivel) | impresos | impresos | OPTIMO | 3-9, 6-10, 7-8 (2), 10-11, 11-13, 13-14 | 28.643 | 717.946 | 715.0813 | 0.0000 % | 13.0 s |
| Reproducido: oraculo (un nivel) | exactos | impresos | OPTIMO | 3-9, 6-10, 7-8 (2), 10-11, 11-13, 13-14 | 28.643 | 717.757 | 714.8926 | 0.0000 % | 14.7 s |
| Reproducido: oraculo (un nivel) | exactos | exactos | OPTIMO | 3-9, 6-10, 7-8 (2), 10-11, 11-13, 13-14 | 28.643 | 717.972 | 715.1072 | 0.0000 % | 14.4 s |
| Reproducido: dualidad (36)-(45) | exactos | exactos | OPTIMO | 3-9, 6-10, 7-8 (2), 10-11, 11-13, 13-14 | 28.643 | 717.972 | 715.1072 | 0.0000 % | 2067.7 s |
