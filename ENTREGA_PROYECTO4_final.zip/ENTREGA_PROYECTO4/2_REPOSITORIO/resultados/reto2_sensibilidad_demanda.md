# Reto 2 - sensibilidad al coeficiente de demanda (Figs. 4 y 5 de Heydari)

Coeficiente relativo r = 0.85...1.15 aplicado sobre el coeficiente base 2.2 (r = 1 reproduce la Tabla 4). Las figuras del paper son graficos de barras 3D sin valores tabulados: se comparan las tendencias descritas en el texto, no cifras.

| r | Caso 1: inv. / ESW | Caso 2: inv. / ESW | Caso 3: inv. / ESW | Caso 4: inv. / ESW |
|---|---:|---:|---:|---:|
| 0.85 | 130.0 / 398.7 | 250.0 / 545.5 | 250.0 / 545.5 | 250.0 / 545.5 |
| 0.90 | 130.0 / 419.8 | 281.0 / 554.5 | 281.0 / 554.5 | 281.0 / 554.5 |
| 0.95 | 180.0 / 442.0 | 311.0 / 550.0 | 294.6 / 549.7 | 294.6 / 549.7 |
| 1.00 | 180.0 / 462.8 | 342.0 / 529.3 | 342.6 / 532.4 | 324.6 / 527.9 |
| 1.05 | 228.0 / 484.5 | 390.0 / 471.2 | 349.2 / 474.2 | 342.6 / 471.9 |
| 1.10 | 282.0 / 506.2 | 390.0 / 366.4 | 379.2 / 380.8 | 349.2 / 375.4 |
| 1.15 | 330.0 / 527.1 | 390.0 / 229.5 | 397.2 / 248.6 | 349.2 / 237.8 |

## Planes

| r | Caso 1 | Caso 2 | Caso 3 | Caso 4 |
|---|---|---|---|---|
| 0.85 | 2-6 (3), 3-5 (2) | 2-6 (4), 3-5 (2), 4-6 (3) | 2-6 (4), 3-5 (2), 4-6 (3) | 2-6 (4), 3-5 (2), 4-6 (3) |
| 0.90 | 2-6 (3), 3-5 (2) | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 |
| 0.95 | 2-6 (4), 3-5 (3) | 2-6 (4), 3-5 (2), 4-6 (3), 5-6 | 2-6 (4), 3-5 (3), 4-6 (2)  |  HVDC: 2-6 | 2-6 (4), 3-5 (3), 4-6 (2)  |  HVDC: 2-6 |
| 1.00 | 2-6 (4), 3-5 (3) | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) | 2-6 (4), 3-5 (3), 3-6, 4-6 (2)  |  HVDC: 2-6 | 2-6 (4), 3-5 (3), 4-6 (3)  |  HVDC: 2-6 |
| 1.05 | 2-6 (4), 3-5 (3), 3-6 | 2-6 (4), 3-5 (2), 3-6, 4-6 (2), 5-6 (2) | 2-6 (4), 3-5 (3), 4-6 (2)  |  HVDC: 2-6 (2) | 2-6 (4), 3-5 (3), 3-6, 4-6 (2)  |  HVDC: 2-6 |
| 1.10 | 2-6 (4), 3-5 (2), 5-6 (2) | 2-6 (4), 3-5 (2), 3-6, 4-6 (2), 5-6 (2) | 2-6 (4), 3-5 (3), 4-6 (3)  |  HVDC: 2-6 (2) | 2-6 (4), 3-5 (3), 4-6 (2)  |  HVDC: 2-6 (2) |
| 1.15 | 2-6 (4), 3-5 (2), 3-6, 5-6 (2) | 2-6 (4), 3-5 (2), 3-6, 4-6 (2), 5-6 (2) | 2-6 (4), 3-5 (3), 3-6, 4-6 (2)  |  HVDC: 2-6 (2) | 2-6 (4), 3-5 (3), 4-6 (2)  |  HVDC: 2-6 (2) |

## Tendencias descritas en el paper (Sec. 4.1.3)

* CONSISTENTE: Caso 1: la inversion crece con el coeficiente de demanda
* CONSISTENTE: Caso 1: el bienestar crece uniformemente con el coeficiente
* CONSISTENTE: Casos 2-4: la inversion crece con el coeficiente (hasta el limite de presupuesto)
* CONSISTENTE: Casos 2-4: el bienestar primero crece y luego decrece (mas racionamiento)
* CONSISTENTE: Casos 2 y 3: misma inversion donde no se instala HVDC (coef. bajos)
* CONSISTENTE: La inversion del caso 3 llega a su meseta (limite de presupuesto) con un coeficiente mayor o igual que la del caso 2, o no llega
* CONSISTENTE: Caso 4: invierte menos o igual que el caso 3 en todos los coeficientes