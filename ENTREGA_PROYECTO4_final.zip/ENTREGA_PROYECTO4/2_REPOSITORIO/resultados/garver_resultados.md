# Reto 1 - Sistema de Garver: reproduccion de Garces et al. (2009)

Candidatos binarios: 39; escenarios: 3; sigma = 8760 h; crf (objetivo) = 0.1; presupuesto = 30.0 M EUR; M = Gamma = 1000; Sbase = 100 MVA.

## 1. Modelo bilevel (Tabla IV, primera fila)

| Formulacion | Estado | Plan | Inversion total (M EUR) | Bienestar medio (M EUR/ano) | Objetivo (1) (M EUR/ano) | CPU (s) | max abs(phi) |
|---|---|---|---:|---:|---:|---:|---:|
| **Paper (Tabla IV)** | - | 3-5, 2-3, 4-6 (3) | 25.10 | 292.71 | - | 6.70 (CPLEX 11) | - |
| Reproducido: dualidad (36)-(45) | OPTIMO | 2-3, 3-5, 4-6 (3) | 25.100 | 292.714 | 290.2040 | 0.46 (Gurobi) | 2.0 |
| Reproducido: oraculo (un nivel) | OPTIMO | 2-3, 3-5, 4-6 (3) | 25.100 | 292.714 | 290.2040 | 0.06 (Gurobi) | - |

Verificacion: el MILP de dualidad fuerte y el oraculo de un nivel dan el mismo objetivo (290.204046 M EUR/ano). Plan, inversion (25.10) y bienestar medio (292.71) coinciden con el paper.

### Sensibilidad a las constantes M y Gamma_max (paper: 1000)

| M | Gamma_max | Plan | Objetivo | CPU (s) |
|---:|---:|---|---:|---:|
| 1000 | 1000 | 2-3, 3-5, 4-6 (3) | 290.204046 | 0.44 |
| 10 | 1000 | 2-3, 3-5, 4-6 (3) | 290.204046 | 0.27 |
| 1000 | 100000 | 2-3, 3-5, 4-6 (3) | 290.204046 | 0.22 |
| 10 | 100000 | 2-3, 3-5, 4-6 (3) | 290.204046 | 0.23 |

El optimo no depende de M ni de Gamma_max en este rango (en el optimo no hay racionamiento y max abs(phi) es pequeno).

## 2. Minimizacion de costos por escenario (Tabla IV, filas 2-4)

Objetivo usado: `0.10*c*x + 8760*cU*r` (inversion anualizada + racionamiento anual), sin presupuesto (2); es la ponderacion que reproduce las inversiones publicadas (la version sin anualizar no construye lineas).

| Aproximacion | Plan paper | Inv. paper | Inv. reprod. | Optimos empatados | Plan paper entre ellos | Bienestar medio paper | Bienestar medio (plan paper, LP primal) | Bienestar medio (plan del solver) |
|---|---|---:|---:|---:|:--:|---:|---:|---:|
| Min-costos Esc. 1 | 3-5, 2-3, 2-6 (2) | 19.31 | 19.308 | 4 | si | -2613.02 | -2613.0261 (OK) | -2600.38 |
| Min-costos Esc. 2 | 3-5, 2-3, 4-6 (3) | 25.10 | 25.100 | 2 | si | 292.71 | 292.7141 (OK) | 292.71 |
| Min-costos Esc. 3 | 3-5, 2-6, 4-6 (2) | 21.24 | 21.239 | 1 | si | -423.57 | -423.5745 (OK) | -423.57 |

Notas:
* La inversion minima coincide en los tres escenarios. Hay **optimos alternativos de igual costo** (2-6 y 4-6 cuestan lo mismo, 5 792.40; 2-3 y 3-5 cuestan lo mismo, 3 861.60). El plan del paper pertenece al conjunto de optimos empatados y, evaluado con el mercado, reproduce el bienestar medio publicado (-2 613.02 y -423.57 exactos). El plan que devuelve el solver puede ser otro optimo empatado, con distinto bienestar medio.
* El bienestar medio se calcula, como en el paper, resolviendo el mercado de cada escenario con el plan fijo. Se usa el LP primal (5)-(19): con racionamiento los precios sombra superan Gamma_max=1000 y la dualidad fuerte (35) del MILP seria infactible (ver `verificaciones_modelo.py`).

### Columna 'Social welfare' por escenario de la Tabla IV (275.60 / 291.50 / 286.62)

| Plan (paper) | SW paper (M EUR) | Mercado despejado con el plan fijo (M EUR) | Paper <= despejado |
|---|---:|---:|:--:|
| Min-costos Esc. 1: 3-5, 2-3, 2-6 (2) | 275.60 | 276.45 | si |
| Min-costos Esc. 2: 3-5, 2-3, 4-6 (3) | 291.50 | 307.79 | si |
| Min-costos Esc. 3: 3-5, 2-6, 4-6 (2) | 286.62 | 303.19 | si |

**No reproducible por construccion**: esas tres cifras salen del despacho del modelo de minimizacion de costos, cuyo objetivo no contiene precios; el despacho es degenerado (depende del vertice que devuelva el solver). Se probaron el mercado despejado, el consumo fijo en el minimo (90 %) y el 100 %, y ninguno da esas cifras. Todas quedan por debajo del bienestar maximo (mercado despejado), coherente con un despacho no optimo para el mercado. Las cifras que determinan las conclusiones (plan, inversion, bienestar medio) si se reproducen.

## 3. Modelo basico y centralizado (tesis, Cuadro 6.4)

| | Plan | Inversion (M EUR) | Bienestar medio (M EUR/ano) |
|---|---|---:|---:|
| Tesis | 3-5, 4-6 (3) | 21.24 | -507.84 |
| Reproducido (demanda fija = 100 % del escenario base, sin racionamiento) | 3-5, 4-6 (3) | 21.239 | -507.84 |

La tesis solo dice 'demanda constante igual al pico previsto'; la definicion que reproduce la cifra es el escenario 1 al 100 %.

## 4. Contingencias simples (Tabla V)

Cuatro escenarios (pesos 0.40/0.25/0.25/0.10); el cuarto saca de servicio el circuito existente indicado.

Se resuelve con la formulacion de dualidad (36)-(45) y, como control, con el oraculo de un nivel (solo primal). 'Racion. max.' es el mayor racionamiento (MW) de un escenario en el plan optimo; 'max abs(phi)' es el mayor |phi| del dual.

| Linea fuera | Plan paper | Plan reproducido | Inv. paper | Inv. reprod. | Bienestar medio paper | Bienestar medio reprod. | Objetivo del plan paper = optimo | Obj. dualidad | Obj. oraculo | Racion. max. (MW) | max abs(phi) | CPU paper (s) | CPU Gurobi dualidad / oraculo (s) |
|---|---|---|---:|---:|---:|---:|:--:|---:|---:|---:|---:|---:|---:|
| 1-2 | 2-3, 3-5, 4-6 (3) | 2-3, 3-5, 4-6 (3) | 25.10 | 25.10 | 292.71 | 292.71 | si | 290.204046 | 290.204046 | 0.00 | 2.0 | 4.19 | 0.61 / 0.03 |
| 1-4 | 2-3, 3-5, 4-6 (3) | 2-3, 3-5, 4-6 (3) | 25.10 | 25.10 | 292.71 | 292.71 | si | 290.204046 | 290.204046 | 0.00 | 2.0 | 1.65 | 0.76 / 0.06 |
| 1-5 | 1-5, 2-3, 3-5, 4-6 (3) | 1-5, 2-3, 3-5, 4-6 (3) | 28.96 | 28.96 | 292.72 | 292.72 | si | 289.819200 | 289.819200 | 0.00 | 2.0 | 5.09 | 0.87 / 0.11 |
| 2-3 | 2-3, 3-5, 4-6 (3) | 2-3, 3-5, 4-6 (3) | 25.10 | 25.10 | 292.53 | 292.53 | si | 290.021573 | 290.021573 | 0.00 | 6.2 | 6.05 | 0.77 / 0.07 |
| 2-4 | 2-3, 3-5, 4-6 (3) | 2-3, 3-5, 4-6 (3) | 25.10 | 25.10 | 292.71 | 292.71 | si | 290.204046 | 290.204046 | 0.00 | 2.0 | 8.80 | 0.37 / 0.06 |
| 3-5 | 2-3, 3-5 (2), 4-6 (3) | 2-3, 3-5 (2), 4-6 (3) | 28.96 | 28.96 | 292.70 | 292.70 | si | 289.807520 | 289.807520 | 0.00 | 2.0 | 23.30 | 0.83 / 0.07 |

(*) plan distinto al publicado: se indica en la columna 'Objetivo del plan paper = optimo' si el plan del paper alcanza el mismo objetivo (optimo alternativo).

## 5. Objetivo alternativo (20) (sin resultado publicado para comparar)

Max (20) = -(racionamiento medio) - inversion: plan = 2-3, 3-5, 4-6 (3), inversion = 25.100 M EUR, bienestar medio = 292.71 M EUR/ano, estado = OPTIMO.
