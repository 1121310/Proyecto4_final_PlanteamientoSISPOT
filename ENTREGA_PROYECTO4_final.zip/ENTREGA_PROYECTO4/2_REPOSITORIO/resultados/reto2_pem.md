# Reto 2 - metodo 2: Point Estimate Method (Hong, 1998)

Para cada bloque de la curva de duracion la intensidad eolica es una variable aleatoria (m = 1) cuya distribucion son los 6 niveles equiprobables del paper; el PEM la sustituye por 2 puntos (esquema 2m) o 3 puntos (2m+1) con pesos de Hong (ver `incertidumbre.py`). Solo casos 2 y 3: el caso 1 no tiene viento y en el caso 4 los pesos del PEM dependen del bloque, de modo que no definen escenarios anuales con probabilidad propia para el CVaR.

## Distribucion de cada bloque y puntos del PEM 2m+1

| Bloque | media | desv. | asimetria | curtosis | puntos (viento p.u. : peso) |
|---|---:|---:|---:|---:|---|
| 1 | 0.2485 | 0.1350 | 0.305 | 1.895 | 0.4515:0.246; 0.0866:0.309; 0.2485:0.445 |
| 2 | 0.2420 | 0.1362 | 0.383 | 2.047 | 0.4577:0.227; 0.0785:0.299; 0.2420:0.474 |
| 3 | 0.2212 | 0.1167 | 0.426 | 2.111 | 0.4100:0.220; 0.0822:0.298; 0.2212:0.482 |
| 4 | 0.2776 | 0.1496 | 0.230 | 1.808 | 0.4938:0.260; 0.0958:0.310; 0.2776:0.430 |
| 5 | 0.2700 | 0.1598 | 0.027 | 1.716 | 0.4816:0.288; 0.0629:0.295; 0.2700:0.417 |

## Exactitud del estimador del bienestar esperado (ESW, M$) para planes fijos

Se evaluan los 4 planes publicados en el sistema con eolica y HVDC (caso 3). El plan del caso 1 (sin HVDC ni refuerzos para el viento) es insuficiente en ese sistema y racionan mucho: da un ESW negativo y sirve de prueba de estres. El error es (PEM - 6 niveles) y su % se calcula sobre |ESW de 6 niveles|.

| Plan (publicado en caso) | 6 niveles (30 LP) | PEM 2m (10 LP) | error | PEM 2m+1 (15 LP) | error |
|---|---:|---:|---:|---:|---:|
| caso 1: 2-6 (4), 3-5 (3) / - | -241.196 | -234.050 | +7.146 (+2.96 %) | -239.674 | +1.522 (+0.63 %) |
| caso 2: 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) / - | 529.305 | 521.028 | -8.277 (-1.56 %) | 533.180 | +3.875 (+0.73 %) |
| caso 3: 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | 532.415 | 521.031 | -11.384 (-2.14 %) | 540.080 | +7.665 (+1.44 %) |
| caso 4: 2-6 (4), 3-5 (3), 4-6 (3) / 2-6 | 527.887 | 521.000 | -6.887 (-1.30 %) | 532.484 | +4.598 (+0.87 %) |

## Plan optimo con cada metodo de incertidumbre

El objetivo de la ultima columna es el del plan evaluado con los 30 mercados de referencia (6 niveles), para comparar planes en la misma vara.

| Caso | Metodo | mercados | Estado | Plan HVAC / HVDC | Inv. (M$) | Objetivo propio | Objetivo con 6 niveles | Arrepentimiento (M$) | t (s) |
|---|---|---:|---|---|---:|---:|---:|---:|---:|
| 2 | 6 niveles (paper) | 30 | OPTIMO | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) / - | 342.0 | 491.628 | 491.628 | 0 | 2.6 |
| 2 | PEM 2m | 10 | OPTIMO | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) / - | 342.0 | 483.351 | 491.628 | 0.000 | 0.4 |
| 2 | PEM 2m+1 | 15 | OPTIMO | 2-6 (4), 3-5 (2), 4-6 (3), 5-6 (2) / - | 372.0 | 499.097 | 491.435 | 0.193 | 1.2 |
| 3 | 6 niveles (paper) | 30 | OPTIMO | 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | 342.6 | 494.672 | 494.672 | 0 | 3.2 |
| 3 | PEM 2m | 10 | OPTIMO | 2-6 (4), 3-5 (3), 4-6 (3) / 2-6 | 324.6 | 485.239 | 492.126 | 2.546 | 0.5 |
| 3 | PEM 2m+1 | 15 | OPTIMO | 2-6 (4), 3-5 (3), 3-6, 4-6 (2) / 2-6 | 342.6 | 502.336 | 494.672 | 0.000 | 1.4 |