# Reto 2 - formulacion de dualidad (55)-(70) frente al MILP de un nivel

Gamma = Gamma' = 10000 (Heydari no da su valor), M = 1000, limite 3600 s. Se anade una corrida con Gamma = 1000 (el valor que usa Garces) para ver si esa cota es activa: con racionamiento los precios sombra llegan a ~10 x el precio de la demanda y los phi a varios miles.

| Caso | Estado (Gamma 1e4) | Plan | Objetivo dualidad | Objetivo un nivel | max abs(phi) | Tiempo dualidad (s) | Con Gamma = 1000 |
|---|---|---|---:|---:|---:|---:|---|
| 1 | OPTIMO | 2-6 (4), 3-5 (3) | 443.0137 | 443.0137 | 50 | 0.2 | OPTIMO, obj 443.0137 (igual); plan publicado fijo: factible |
| 2 | OPTIMO | 2-6 (4), 3-5 (2), 4-6 (2), 5-6 (2) | 491.6279 | 491.6279 | 4984 | 10.8 | OPTIMO, obj 491.6279 (igual); plan publicado fijo: factible |
| 3 | OPTIMO | 2-6 (4), 3-5 (3), 3-6, 4-6 (2)  |  HVDC: 2-6 | 494.6716 | 494.6716 | 10 | 14.1 | OPTIMO, obj 494.6716 (igual); plan publicado fijo: factible |
| 4 | OPTIMO | 2-6 (4), 3-5 (3), 4-6 (3)  |  HVDC: 2-6 | 1664.7122 | 1664.7122 | 4491 | 10.1 | OPTIMO, obj 1657.2857 (DIFIERE); plan publicado fijo: INFACT_o_NOACOT |