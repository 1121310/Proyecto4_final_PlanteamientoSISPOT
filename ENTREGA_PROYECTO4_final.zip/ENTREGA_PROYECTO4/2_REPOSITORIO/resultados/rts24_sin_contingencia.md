# Reto 1 - IEEE RTS-24, caso sin contingencias (Tabla VIII)

Circuitos candidatos (binarios): 85; escenarios: 3; presupuesto = 23.0 M EUR; M = Gamma_max = 1000.

**Dos variantes de los bloques de la Tabla VI** (mismos totales por barra y mismos precios):

* *impresos*: los tamanos de bloque tal como aparecen en la tabla (redondeados, p. ej. 259 / 32.5 / 32.5 en la barra 1).
* *exactos*: reparto 80/10/10 % de la demanda total y 40/30/30 % de la capacidad de cada generador (barra 1: 259.2 / 32.4 / 32.4 y 230.4 / 172.8 / 172.8). **Es una inferencia, no un dato publicado**: la tabla impresa es el redondeo de este reparto (desviacion maxima 0.6 MW) y, como se ve en la seccion 3, reproduce las cuatro cifras de bienestar medio de la Tabla VIII con error <= 0.003 M EUR, cosa que los bloques impresos no logran.

## 1. Modelo bilevel

| Formulacion | Estado | Plan | Inversion (M EUR) | Bienestar medio (M EUR/ano) | Objetivo (1) | CPU (s) | max abs(phi) |
|---|---|---|---:|---:|---:|---:|---:|
| **Paper (Tabla VIII)** | - | 6-10, 10-11, 11-13, 14-23 | 22.99 | 742.59 | - | 89.51 (CPLEX 11) | - |
| Reproducido, bloques exactos: dualidad (36)-(45) | OPTIMO | 6-10, 10-11, 11-13, 14-23 | 22.988 | 742.589 | 740.2906 | 4.2 (Gurobi) | 242.0 |
| Reproducido, bloques exactos: oraculo | OPTIMO | 6-10, 10-11, 11-13, 14-23 | 22.988 | 742.589 | 740.2906 | 0.3 (Gurobi) | - |
| Reproducido, bloques impresos: dualidad | OPTIMO | 6-10, 10-11, 11-13, 14-23 | 22.988 | 742.777 | 740.4785 | 4.4 (Gurobi) | 242.0 |

Con ambas variantes se obtiene el plan publicado (6-10, 10-11, 11-13, 14-23) y su inversion (22.99). El bienestar medio con bloques exactos coincide con el paper (742.59).

## 2. Minimizacion de costos por escenario

Mismo objetivo que en Garver: `0.10*c*x + 8760*cU*r`, sin presupuesto.

| Aproximacion | Plan paper | Inv. paper | Plan del solver | Inv. reprod. | Optimos empatados | Plan paper entre ellos | CPU (s) |
|---|---|---:|---|---:|---:|:--:|---:|
| Min-costos Esc. 1 | 6-7, 7-8, 13-14 | 9.02 | 6-7, 7-8, 13-14 | 9.022 | 1 | si | 0.1 |
| Min-costos Esc. 2 | 6-7 (2), 7-8, 2-8, 11-13 | 17.48 | 2-8, 6-7 (2), 7-8, 11-13 | 17.484 | 1 | si | 0.1 |
| Min-costos Esc. 3 | 6-10, 7-8 (2), 13-14 | 9.13 | 6-10, 7-8 (2), 13-14 | 9.126 | 1 | si | 0.1 |

## 3. Bienestar medio de cada plan publicado (mercado de los 3 escenarios con el plan fijo)

| Plan | Paper | Bloques impresos | Dif. | Bloques exactos | Dif. | Racionamiento por escenario (MW) |
|---|---:|---:|---:|---:|---:|---|
| Bilevel: 6-10, 10-11, 11-13, 14-23 | 742.59 | 742.777 | +0.187 | 742.589 | -0.001 | 0.0, 0.0, 0.0 |
| Min-costos Esc. 1: 6-7, 7-8, 13-14 | -2430.44 | -2430.253 | +0.187 | -2430.440 | +0.000 | 0.0, 145.7, 5.0 |
| Min-costos Esc. 2: 6-7 (2), 7-8, 2-8, 11-13 | 687.17 | 687.354 | +0.184 | 687.167 | -0.003 | 0.0, 0.0, 0.0 |
| Min-costos Esc. 3: 6-10, 7-8 (2), 13-14 | -1399.75 | -1399.566 | +0.184 | -1399.753 | -0.003 | 0.0, 95.5, 0.0 |

Con los bloques impresos las cuatro cifras quedan desplazadas entre +0.184 y +0.187 M EUR/ano (~0.025 %), un desplazamiento casi constante, igual en planes con y sin racionamiento (no es un efecto de red). Con los bloques exactos el error maximo es 0.003 M EUR/ano (<= redondeo del paper). Conclusion: el modelo reproduce el paper; la discrepancia con los datos impresos es de redondeo de la Tabla VI. Ningun parametro del modelo se ajusto para forzar el acuerdo.
